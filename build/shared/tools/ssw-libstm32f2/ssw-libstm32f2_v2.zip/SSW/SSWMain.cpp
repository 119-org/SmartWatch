extern "C"{
  
void _init(){};

/**
 * @brief Disables all peripheral interrupts except USB and fades the
 *        error LED.
 */
/* (Called from exc.S with global interrupts disabled.) */
void __error(int num) {
    /*nvic_globalirq_enable();
    usart_putstr(ERROR_USART, "\r\nexception: ");
    usart_putudec(ERROR_USART, num);
    usart_putc(ERROR_USART, '\n');
    usart_putc(ERROR_USART, '\r');
	for(;;);
    throb();
	
	// Turn off peripheral interrupts
    nvic_irq_disable_all();

    // Turn off timers 
    timer_disable_all();

    // Turn off ADC 
    adc_disable_all();

    // Turn off all USARTs 
    usart_disable_all();

    // Turn the USB interrupt back on so the bootloader keeps on functioning 
    nvic_irq_enable(NVIC_USB_HP_CAN_TX);
    nvic_irq_enable(NVIC_USB_LP_CAN_RX0);

    // Reenable global interrupts 
    nvic_globalirq_enable();
    throb();
    */
}

}

#include "stm32f2xx_dma.h"
#include "stm32f2xx_rcc.h"
#include "stm32f2xx_spi.h"
#include "stm32f2xx_gpio.h"

void init() {
  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_DMA2, ENABLE);
}

void setup();
void loop();

int main(void) {
  init();
  setup();
	while(1) loop();
	return 0;
}

#include "../sketch/ssw.ino"
